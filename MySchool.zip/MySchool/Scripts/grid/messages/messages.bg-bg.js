﻿gj.grid.messages['bg-bg'] = {
    First: 'Първа',
    Previous: 'Предишна',
    Next: 'Следваща',
    Last: 'Последна',
    Page: 'Страница',
    FirstPageTooltip: 'Първа Страница',
    PreviousPageTooltip: 'Предишна Страница',
    NextPageTooltip: 'Следваща Страница',
    LastPageTooltip: 'Последна Страница',
    Refresh: 'Презареждане',
    Of: 'от',
    DisplayingRecords: 'Паказани записи',
    Edit: 'Редактиране',
    Delete: 'Изтриване',
    Update: 'Актуализация',
    Cancel: 'Отказ',
    NoRecordsFound: 'Няма намерени записи.'
};