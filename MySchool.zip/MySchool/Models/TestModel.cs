﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MySchool.Models
{
    public class TestModel
    {
        public string Message { get; set; }
    }
}