﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MySchool.Models
{
    public class UserModel
    {
        public string UserName { get; set; }
        public string FullName { get; set; }
        public string Password { get; set; }
        public string Person_Id { get; set; }
        public string UserNameString { get; set; }
        public static List<UserModel> GetUsers(string searchString = null)
        {
           
         List<Models.UserModel> records=new List<Models.UserModel>() ;
         
           //To do Prevent input from Sql injection

                 

            try
            {
                
                string dbConString = "Server=WEB4;Database=ClientDatabase;User ID=sa;Password=hrms;Trusted_Connection=False;";
                string sq_stmt = "select Username,[Password],First_name+' '+Last_name as FullName,Person.Person_id from Person join Users on Person.Person_id=Users.Person_id";
               if(searchString!=null)
               {
                   sq_stmt = string.Format("select Username,[Password],First_name+' '+Last_name as FullName,Person.Person_id from Person join Users on Person.Person_id=Users.Person_id where UserName='{0}'", searchString);
                    

               }

                using (SqlConnection dbCon = new SqlConnection(dbConString))
                {
                    dbCon.Open();

                    using (SqlCommand dbCom = new SqlCommand(sq_stmt, dbCon))
                    {
                        

                        using (SqlDataReader wizReader = dbCom.ExecuteReader())
                        {
                            while (wizReader.Read())
                            {
                                var p = new UserModel()
                                {
                                    UserName = (string)wizReader["Username"],
                                    FullName = (string)wizReader["FullName"],
                                    Password = (string)wizReader["Password"],
                                    UserNameString = (string)wizReader["FullName"] + "(" + (string)wizReader["Username"] + ")",
                                    Person_Id = wizReader["Person_id"].ToString()

                                };

                                records.Add(p);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                
            }
            return records;
        }

        public static bool UserExist(UserModel userdata)
        {


            bool exist = false;
            try
            {


                string dbConString = "Server=WEB4;Database=ClientDatabase;User ID=sa;Password=hrms;Trusted_Connection=False;";
                string sq_stmt = string.Format("Select [Username] from Users where [Username]=''", userdata.UserName);


                using (SqlConnection dbCon = new SqlConnection(dbConString))
                {
                    dbCon.Open();

                    using (SqlCommand dbCom = new SqlCommand(sq_stmt, dbCon))
                    {

                        using (SqlDataReader wizReader = dbCom.ExecuteReader())
                        {
                            while (wizReader.Read())
                            {
                                exist = true;
                            }
                        }

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return exist;

        }
        public static int UpdateUser(UserModel userdata)
        {


            int ret = -1;
            try
            {


                string dbConString = "Server=WEB4;Database=ClientDatabase;User ID=sa;Password=hrms;Trusted_Connection=False;";
                string sq_stmt = string.Format("update [Users] set Username='{0}',[Password]='{1}' where Person_id='{2}'", userdata.UserName, userdata.Password, userdata.Person_Id);


                using (SqlConnection dbCon = new SqlConnection(dbConString))
                {
                    dbCon.Open();

                    using (SqlCommand dbCom = new SqlCommand(sq_stmt, dbCon))
                    {

                        ret = dbCom.ExecuteNonQuery();

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return ret;

        }

        public static int AddUser(UserModel userdata)
        {


            int ret = -1;
            try
            {


                string dbConString = "Server=WEB4;Database=ClientDatabase;User ID=sa;Password=hrms;Trusted_Connection=False;";
                string sq_stmt = string.Format("insert into [Users] values('{0}','{1}','{2}')",userdata.Person_Id, userdata.UserName, userdata.Password);


                using (SqlConnection dbCon = new SqlConnection(dbConString))
                {
                    dbCon.Open();

                    using (SqlCommand dbCom = new SqlCommand(sq_stmt, dbCon))
                    {

                        ret = dbCom.ExecuteNonQuery();

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return ret;

        }

        public static int DeleteUser(UserModel userdata)
        {


            int ret = -1;
            try
            {


                string dbConString = "Server=WEB4;Database=ClientDatabase;User ID=sa;Password=hrms;Trusted_Connection=False;";
                string sq_stmt = string.Format("delete from [Users] where Username='{0}'",userdata.UserName);


                using (SqlConnection dbCon = new SqlConnection(dbConString))
                {
                    dbCon.Open();

                    using (SqlCommand dbCom = new SqlCommand(sq_stmt, dbCon))
                    {

                        ret = dbCom.ExecuteNonQuery();

                    }
                }
            }
            catch (Exception ex)
            {

            }
            return ret;

        }
        
            
    }
    
}