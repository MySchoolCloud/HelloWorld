﻿using MySchool.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Middleware.BaseClass;
namespace MySchool.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult UserRoles()
        {
            return View();
        }
        public ActionResult User()
        {
            return PartialView();
        }
        public ActionResult Roles()
        {
            return PartialView();
        }
        [HttpGet]
        public JsonResult GetUsers(int? page, int? limit,
        string sortBy, string direction, string searchString = null)
        {

            var records = MySchool.Models.UserModel.GetUsers(searchString);
            var total = records.ToList().Count();
            
            return Json(new { records, total }, JsonRequestBehavior.AllowGet);
        }
        
        [HttpPost]
        public JsonResult Save(UserModel userdata, bool isUpdate)
        {
            if(isUpdate)
            {
                UserModel.UpdateUser(userdata);
            }
            else
            {
                if(string.IsNullOrEmpty(userdata.Person_Id))
                {
                    string[] namestring = userdata.FullName.Split(' ');
                    userdata.Person_Id = Person.GetNewId();
                    Person persondata = new Person();
                    persondata.FirstName = namestring[0];
                    persondata.LastName = namestring[1];
                    persondata.Person_Id = userdata.Person_Id;
                    Person.AddPerson(persondata);
                }
                UserModel.AddUser(userdata);
            }
            return Json(true);
        }

        [HttpPost]
        public JsonResult Remove(UserModel userdata)
        {
            UserModel.DeleteUser(userdata);
            return Json(true);
        }
       
        [HttpPost]
        public JsonResult GetUserList(string Prefix)
        {

            List<MySchool.Models.UserModel> ObjList = new List<MySchool.Models.UserModel>();
            ObjList = MySchool.Models.UserModel.GetUsers();
            //Searching records from list using LINQ query  
            var NameString = (from N in ObjList
                            where N.UserNameString.ToLower().Contains(Prefix.ToLower())
                            select new { N.UserNameString,N.UserName });
            return Json(NameString, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetPersonList(string Prefix)
        {

            List<MySchool.Models.PersonAutoCompleteViewModel> ObjList = new List<MySchool.Models.PersonAutoCompleteViewModel>();
            ObjList = MySchool.Models.PersonAutoCompleteViewModel.GetPersons();
            //Searching records from list using LINQ query  
            var NameString = (from N in ObjList
                              where N.FullName.ToLower().Contains(Prefix.ToLower())
                              select new { N.FullName,N.Person_Id});
            return Json(NameString, JsonRequestBehavior.AllowGet);
        }  
    }
}